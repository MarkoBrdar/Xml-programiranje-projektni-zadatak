<?php
// Učitavanje JSON datoteke
$jsonData = file_get_contents('filmovi.json');
$data = json_decode($jsonData, true);
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Popis Filmova</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <style>
        .body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .content {
            flex: 1;
        }
        footer {
            background-color: #f8f9fa;
            padding: 10px 0;
            text-align: center;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
        .hidden {
            display: none;
        }
        .nav-link {
            color: whitesmoke;
            font-weight: bold;
        }
        .navbar-brand {
            color: yellow;
            font-weight: bold;
        }
    </style>

    <script>
        function filterTrilogies() {
            const input = document.getElementById('searchTrilogy').value.toLowerCase();
            const trilogyDivs = document.getElementsByClassName('trilogy');

            for (let i = 0; i < trilogyDivs.length; i++) {
                const trilogy = trilogyDivs[i];
                const title = trilogy.getElementsByTagName('h2')[0].textContent.toLowerCase();
                if (input === '' || !title.includes(input)) {
                    trilogy.classList.add('hidden');
                } else {
                    trilogy.classList.remove('hidden');
                }
            }
        }

        window.onload = function() {
            filterTrilogies(); 
        };
    </script>
</head>

<body style="background-color:teal;color: whitesmoke; ">
    <!-- Navigacija -->
    <nav class="navbar navbar-expand-lg navbar-light bg-orangered"  >
        <div class="container-fluid" style="background-color: orangered;">
            <a class="navbar-brand" href="#">HFP.hr</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.html">Naslovna</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="popis.php">Popis</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="o_nama.html">O nama</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4 content">
        <h1>Popis filmova</h1>
        
        <!-- Search bar -->
        <div class="mb-4">
            <input type="text" id="searchTrilogy" onkeyup="filterTrilogies()" class="form-control" placeholder="Pretraži trilogije...">
        </div>

        <?php foreach ($data['trilogije'] as $trilogija): ?>
            <div class="trilogy mb-4 hidden" >
                <h2><?php echo htmlspecialchars($trilogija['naziv']); ?></h2>
                <table class="table " style="color: whitesmoke; font-weight: bold;" >
                    <thead>
                        <tr>
                            <th>Naslov</th>
                            <th>Autor</th>
                            <th>Godina Prikazivanja</th>
                            <th>Duljina Trajanja</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($trilogija['filmovi'] as $film): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($film['naslov']); ?></td>
                                <td><?php echo htmlspecialchars($film['autor']); ?></td>
                                <td><?php echo htmlspecialchars($film['godina']); ?></td>
                                <td><?php echo htmlspecialchars($film['duljina']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div> 
        <?php endforeach; ?>
    </div>

    <footer style="background-color: orangered;">

        <div class="bg-light text-center">
            <div class="text-center" style="color: black;  background-color: orangered;">
                <p style="font-weight: bold;">Marko Brdar</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>

</html>
